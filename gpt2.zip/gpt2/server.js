const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const https = require('https');

const OPENAI_API_KEY = 'your key'; // OpenAI API key
const AZURE_SPEECH_KEY = 'your key'; // Azure Speech key
const AZURE_SPEECH_REGION = 'your key'; // Azure Speech region

const app = express();
app.use(bodyParser.json());
app.use(cors());

const upload = multer({ dest: 'uploads/' });
app.use(express.static(path.join(__dirname, 'public')));

const agent = new https.Agent({
  rejectUnauthorized: false
});

app.post('/api/generate', async (req, res) => {
  const { text } = req.body;
  try {
    const newsContent = text;

    const summaryResponse = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "你是一個有幫助的助手。" },
        { role: "user", content: `新聞內容是英文就用英文生成，是中文就用中文\n${newsContent}` },
        { role: "user", content: `請摘要以下新聞內容：(給我內容就好，越短越好，符合輸入語言)\n\n${newsContent}` }
      ],
      max_tokens: 100,
    }, {
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      httpsAgent: agent
    });

    const summary = summaryResponse.data.choices[0].message.content.trim();

    const topicsResponse = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "你是一個有幫助的助手。" },
        { role: "user", content: `根據以下新聞摘要，生成三個可以聊天的生活化話題：(給我內容就好)\n\n${summary}` },
        { role: "user", content: `摘要是何種語言就輸出該語言的話題,例如摘要是英文就用英文生成，是中文就用中文\n\n${summary}` }
      ],
      max_tokens: 200,
    }, {
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      httpsAgent: agent
    });

    const topics = topicsResponse.data.choices[0].message.content.trim();

    res.json({ newsContent, summary, topics });
  } catch (error) {
    console.error('Error occurred:', error.response ? error.response.data : error.message);
    res.status(500).send('Error processing request');
  }
});

app.post('/api/transcribe', upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) {
      throw new Error('No audio file uploaded');
    }

    const audioPath = req.file.path;
    const audioBuffer = fs.readFileSync(audioPath);

    console.log('Audio Path:', audioPath); 
    console.log('Audio Buffer Size:', audioBuffer.length); 
    console.log('Audio MIME Type:', req.file.mimetype); 

    const { data } = await axios.post(`https://${AZURE_SPEECH_REGION}.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language=zh-CN`, audioBuffer, {
      headers: {
        'Ocp-Apim-Subscription-Key': AZURE_SPEECH_KEY,
        'Content-Type': 'audio/wav'
      }
    });

    console.log('Azure Speech API Response:', data); 

    const transcript = data.DisplayText;
    fs.unlinkSync(audioPath);

    const summaryResponse = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "你是一個有幫助的助手。" },
        { role: "user", content: `請摘要以下內容：\n\n${transcript}` }
      ],
      max_tokens: 200,
    }, {
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      httpsAgent: agent
    });

    console.log('OpenAI Summary Response:', summaryResponse.data); 

    const summary = summaryResponse.data.choices[0].message.content.trim();

    const topicsResponse = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "你是一個有幫助的助手。" },
        { role: "user", content: `根據以下內容摘要，生成三個可以聊天的話題：\n\n${summary}` }
      ],
      max_tokens: 200,
    }, {
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      httpsAgent: agent
    });

    console.log('OpenAI Topics Response:', topicsResponse.data); 

    const topics = topicsResponse.data.choices[0].message.content.trim();

    res.json({ transcript, summary, topics });
  } catch (error) {
    console.error('Error occurred:', error.response ? error.response.data : error.message);
    res.status(500).send('Error processing request');
  }
});

app.listen(3002, () => {
  console.log('Server is running on port 3002');
});
