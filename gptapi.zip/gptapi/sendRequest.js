import fetch from 'node-fetch';

// 需要发送的文本内容
const textContent = "受到Alphabet、特斯拉第二季財報利空影響，美國科技股重挫，導致美股四大指數暴跌。台積電ADR跟隨下跌，費城半導體指數跌幅達5%。投資人憂慮若正常開市，台股可能補跌。財信傳媒董事長謝金河表示，台股高掛免戰牌，預料開盤可能凶多吉少。昨日美股指數全面下跌，包括道瓊指數下跌1.25%。";

// 使用 fetch 发送 POST 请求
fetch('http://localhost:5001/api/generate', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json; charset=UTF-8',
  },
  body: JSON.stringify({ text: textContent })
})
  .then(response => {
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
  })
  .then(data => {
    console.log('Summary:', data.summary);
    console.log('Topics:', data.topics);
  })
  .catch(error => {
    console.error('Error:', error);
  });
